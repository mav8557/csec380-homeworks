# To Run:

docker build -t step2 .
docker run --rm -v $PWD/staff:/staff step2
