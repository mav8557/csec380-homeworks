# To Run:

docker build -t act2 .
docker run --rm -v $PWD:/tmp/outdir/ act2