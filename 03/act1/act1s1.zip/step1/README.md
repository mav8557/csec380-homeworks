# To Run:

docker build -t step1 .
docker run --rm -v $PWD:/ih8docker step1
